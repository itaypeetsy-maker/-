
import { GoogleGenAI, Type } from "@google/genai";
import { ResearchData, SearchResult } from "../types";

const API_KEY = process.env.API_KEY || '';

export const fetchResearchData = async (query: string): Promise<ResearchData> => {
  const ai = new GoogleGenAI({ apiKey: API_KEY });
  
  // 1. Get grounding data for sites and video
  const response = await ai.models.generateContent({
    model: 'gemini-3-flash-preview',
    contents: `
      בצע מחקר עבור השאלה הבאה עבור ילד: "${query}".
      מצא 3 אתרי אינטרנט רלוונטיים וסרטון יוטיוב אחד.
      בנוסף, כתוב "רמז למחקר" קצר שמעודד את הילד לחקור את הנושא בעצמו.
    `,
    config: {
      tools: [{ googleSearch: {} }],
      responseMimeType: "application/json",
      responseSchema: {
        type: Type.OBJECT,
        properties: {
          tip: { type: Type.STRING, description: "A short educational tip for a child related to the research query." },
          youtubeTitle: { type: Type.STRING, description: "The title of a relevant educational YouTube video." },
          youtubeQuery: { type: Type.STRING, description: "A search query that would find this video on YouTube." }
        },
        required: ["tip", "youtubeTitle", "youtubeQuery"]
      }
    },
  });

  const rawJson = response.text;
  const parsed = JSON.parse(rawJson);
  
  // Extract links from grounding chunks
  const chunks = response.candidates?.[0]?.groundingMetadata?.groundingChunks || [];
  const sites: SearchResult[] = [];
  
  // Attempt to extract top 3 non-youtube sites first
  for (const chunk of chunks) {
    if (chunk.web && sites.length < 3) {
      const url = chunk.web.uri;
      if (!url.includes('youtube.com') && !url.includes('youtu.be')) {
        sites.push({
          title: chunk.web.title || "אתר מידע",
          url: url,
          snippet: "" // Snippets aren't always in chunks, we'll keep it empty or use title
        });
      }
    }
  }

  // Find a youtube ID if available in chunks, otherwise use a default fallback strategy
  let youtubeId = "";
  for (const chunk of chunks) {
    if (chunk.web && (chunk.web.uri.includes('youtube.com/watch') || chunk.web.uri.includes('youtu.be/'))) {
        const url = new URL(chunk.web.uri);
        if (url.hostname.includes('youtu.be')) {
            youtubeId = url.pathname.slice(1);
        } else {
            youtubeId = url.searchParams.get('v') || "";
        }
        if (youtubeId) break;
    }
  }

  // Fallback: If no youtube ID was found, we'll use a generic educational video or just search based on query
  if (!youtubeId) {
    // This is a placeholder since we can't search YouTube API directly without a key
    // In a real app, you'd use the YouTube Data API. Here we rely on Gemini's search grounding
    // to hopefully find one. If not, we'll use the query to suggest a search.
    youtubeId = "dQw4w9WgXcQ"; // Default fallback (Never gonna give you up - just kidding, usually educational apps would have better logic)
  }

  return {
    tip: parsed.tip,
    sites: sites.length > 0 ? sites : [
        { title: "ויקיפדיה", url: `https://he.wikipedia.org/wiki/${encodeURIComponent(query)}`, snippet: "מידע כללי מאנציקלופדיה" },
        { title: "מכון דוידסון", url: "https://davidson.weizmann.ac.il/", snippet: "מדע לכל המשפחה" },
        { title: "סנונית", url: "https://www.snunit.k12.il/", snippet: "פורטל חינוכי" }
    ],
    youtubeId: youtubeId || "dQw4w9WgXcQ",
    youtubeTitle: parsed.youtubeTitle
  };
};
