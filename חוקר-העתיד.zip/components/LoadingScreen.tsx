
import React from 'react';

const LoadingScreen: React.FC = () => {
  return (
    <div className="flex flex-col items-center justify-center min-h-[60vh] text-center p-6">
      <div className="relative w-24 h-24 mb-8">
        <div className="absolute top-0 left-0 w-full h-full border-8 border-blue-100 rounded-full"></div>
        <div className="absolute top-0 left-0 w-full h-full border-8 border-blue-600 rounded-full border-t-transparent animate-spin"></div>
      </div>
      <h2 className="text-3xl font-bold text-gray-800 mb-4">מארגן את מרחב הלמידה...</h2>
      <p className="text-gray-500 text-xl max-w-md">
        אני מחפש עבורך את האתרים והסרטונים הכי מעניינים שיעזרו לך למצוא את התשובה!
      </p>
    </div>
  );
};

export default LoadingScreen;
