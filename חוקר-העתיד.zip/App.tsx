
import React, { useState } from 'react';
import Header from './components/Header';
import LoadingScreen from './components/LoadingScreen';
import ResultsPage from './components/ResultsPage';
import { fetchResearchData } from './services/geminiService';
import { AppState, ResearchData } from './types';

const App: React.FC = () => {
  const [status, setStatus] = useState<AppState>(AppState.HOME);
  const [query, setQuery] = useState('');
  const [results, setResults] = useState<ResearchData | null>(null);
  const [error, setError] = useState<string | null>(null);

  const handleSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!query.trim()) return;

    setStatus(AppState.LOADING);
    setError(null);

    try {
      const data = await fetchResearchData(query);
      setResults(data);
      setStatus(AppState.RESULTS);
    } catch (err) {
      console.error(err);
      setError('אופס, משהו השתבש בחיפוש. כדאי לנסות שוב בעוד כמה רגעים.');
      setStatus(AppState.ERROR);
    }
  };

  const handleBack = () => {
    setStatus(AppState.HOME);
    setQuery('');
    setResults(null);
    setError(null);
  };

  return (
    <div className="min-h-screen bg-white text-right" dir="rtl">
      {status === AppState.HOME && (
        <div className="flex flex-col items-center justify-center min-h-[90vh] px-6 animate-fade-in">
          <Header />
          
          <form onSubmit={handleSearch} className="w-full max-w-lg mt-8">
            <div className="relative group">
              <input
                type="text"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
                placeholder="מה תרצו לחקור היום?"
                className="w-full px-6 py-5 text-xl rounded-2xl border-2 border-gray-200 focus:border-blue-500 focus:outline-none transition-all shadow-sm hover:shadow-md pr-14"
              />
              <div className="absolute left-4 top-1/2 -translate-y-1/2 text-gray-400">
                <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                </svg>
              </div>
            </div>
            
            <button
              type="submit"
              disabled={!query.trim()}
              className="w-full mt-6 bg-blue-600 hover:bg-blue-700 text-white font-bold py-5 rounded-2xl text-xl shadow-lg transition-all transform active:scale-[0.98] flex items-center justify-center gap-3 disabled:bg-gray-300 disabled:cursor-not-allowed"
            >
              <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" viewBox="0 0 20 20" fill="currentColor">
                <path fillRule="evenodd" d="M12.395 2.553a1 1 0 00-1.45-.385c-.345.23-.614.558-.822.88-.214.33-.403.713-.57 1.116-.334.804-.614 1.768-.84 2.734a31.365 31.365 0 00-.613 3.58 2.64 2.64 0 01-.945-1.067c-.328-.68-.398-1.534-.398-2.454A1 1 0 005.5 6a1 1 0 00-.5.134 6.017 6.017 0 00-2.812 5.625c.18 5.835 5.939 10.798 10.5 10.798 3.729 0 6.66-3.127 6.66-6.666 0-3.356-1.564-6.326-3.953-8.336zM13 16a2 2 0 11-4 0 2 2 0 014 0z" clipRule="evenodd" />
              </svg>
              התחל במחקר
            </button>
          </form>

          {error && (
            <div className="mt-6 p-4 bg-red-50 text-red-600 rounded-xl border border-red-100 max-w-md text-center">
              {error}
            </div>
          )}
        </div>
      )}

      {status === AppState.LOADING && <LoadingScreen />}

      {status === AppState.RESULTS && results && (
        <ResultsPage data={results} query={query} onBack={handleBack} />
      )}

      {status === AppState.ERROR && (
        <div className="flex flex-col items-center justify-center min-h-[60vh] p-6 text-center">
          <div className="text-red-500 mb-6">
            <svg xmlns="http://www.w3.org/2000/svg" className="h-20 w-20 mx-auto" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
            </svg>
          </div>
          <h2 className="text-2xl font-bold text-gray-800 mb-4">{error}</h2>
          <button 
            onClick={handleBack}
            className="bg-blue-600 text-white px-8 py-3 rounded-xl font-bold hover:bg-blue-700 transition-colors"
          >
            חזרה לחיפוש
          </button>
        </div>
      )}
    </div>
  );
};

export default App;
