
export interface SearchResult {
  title: string;
  url: string;
  snippet: string;
}

export interface ResearchData {
  tip: string;
  sites: SearchResult[];
  youtubeId: string;
  youtubeTitle: string;
}

export enum AppState {
  HOME = 'HOME',
  LOADING = 'LOADING',
  RESULTS = 'RESULTS',
  ERROR = 'ERROR'
}
